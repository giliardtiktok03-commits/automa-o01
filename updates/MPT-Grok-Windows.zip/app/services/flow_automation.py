"""Visible-UI Flow automation. No private endpoints, retries or bypasses."""
import re
import time
from urllib.parse import urlparse

from app.services.flow_browser import FlowError, FlowRefusal, _save_image

MODEL = 'Nano Banana 2.1'


def _one_visible(locator, label):
    matches = [locator.nth(i) for i in range(locator.count()) if locator.nth(i).is_visible()]
    if len(matches) != 1:
        raise FlowError(f'Flow control missing or ambiguous: {label}. No generation was submitted.')
    return matches[0]


def _button(page, pattern, label):
    return _one_visible(page.get_by_role('button', name=re.compile(pattern, re.I)), label)


def _blocked(page, previous_alerts=None):
    if urlparse(page.url).hostname != 'flow.google.com':
        raise FlowError('Flow session needs manual login; no automatic login or account change')
    body = page.locator('body').inner_text(timeout=3000)
    if previous_alerts is not None:
        alerts = set(page.locator('[role="alert"]').all_inner_texts()) - previous_alerts
        if any(re.search(r'request was rejected by the safety|violates our policies|violates.*policy|não foi possível gerar.*segurança|pedido.*recusado.*segurança', text, re.I) for text in alerts):
            raise FlowRefusal('Flow explicitly refused the request; no resubmission')
    if re.search(r'verify you are human|confirme que você é humano|unusual traffic|limite.*atingido|quota exceeded|insufficient credits|créditos insuficientes', body, re.I):
        raise FlowError('Flow quota or verification blocked generation; resolve manually, no retry')
    captcha = page.locator('iframe[src*="recaptcha"], iframe[src*="hcaptcha"]')
    if any(captcha.nth(i).is_visible() for i in range(captcha.count())):
        raise FlowError('Flow requires CAPTCHA; automation stopped')


def _choose(page, text):
    node = _one_visible(page.get_by_text(text, exact=True), text)
    node.click(timeout=5000)
    # Only documented public UI state counts as selection evidence.
    selected = [node.get_attribute(k) for k in ('aria-pressed','aria-selected','aria-checked','data-state')]
    parent = node.locator('xpath=..')
    selected += [parent.get_attribute(k) for k in ('aria-pressed','aria-selected','aria-checked','data-state')]
    if not any(v in ('true','on','checked','active') for v in selected):
        raise FlowError(f'Cannot confirm selected Flow option: {text}. No generation was submitted.')


def _images(page):
    result = {}
    images = page.locator('img')
    for i in range(images.count()):
        node = images.nth(i)
        if node.is_visible() and node.evaluate('(el) => el.complete && el.naturalWidth >= 128 && el.naturalHeight >= 128'):
            src = node.get_attribute('src')
            if src:
                result[src] = node
    return result


def generate(page, prompt, target, timeout=900, require_zero=True):
    from app.services.ai33.policy import reject_legacy_generation
    reject_legacy_generation()
